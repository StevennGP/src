-- Copyright 2006-2020 Mitchell. See LICENSE.
-- Null LPeg lexer.

return require('lexer').new('null')
